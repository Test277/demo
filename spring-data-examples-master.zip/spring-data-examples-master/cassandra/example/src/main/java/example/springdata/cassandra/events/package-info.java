/**
 * Package usage of Lifecycle events.
 */
package example.springdata.cassandra.events;
